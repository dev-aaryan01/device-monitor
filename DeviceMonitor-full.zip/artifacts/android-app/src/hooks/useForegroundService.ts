import { useCallback, useEffect, useState } from "react";

/**
 * useForegroundService
 *
 * In the browser (dev mode) this is a no-op shim so the UI renders normally.
 * When running inside the Capacitor WebView on Android, it calls through to
 * BatteryMonitorPlugin (the native Kotlin foreground service).
 *
 * The Capacitor bridge is accessed via window.Capacitor.Plugins so there is
 * no compile-time import needed — the plugin is registered in MainActivity.java
 * and injected at runtime.
 */

interface ForegroundServiceState {
  isNative: boolean;
  isRunning: boolean;
  start: (threshold: number, frequency: number) => Promise<void>;
  stop: () => Promise<void>;
}

function getPlugin() {
  const w = window as unknown as {
    Capacitor?: {
      isNativePlatform?: () => boolean;
      Plugins?: {
        BatteryMonitorPlugin?: {
          startMonitor: (opts: { threshold: number; frequency: number }) => Promise<void>;
          stopMonitor: () => Promise<void>;
          getStatus: () => Promise<{ enabled: boolean; threshold: number }>;
        };
      };
    };
  };
  return w.Capacitor?.Plugins?.BatteryMonitorPlugin ?? null;
}

export function useForegroundService(): ForegroundServiceState {
  const isNative = !!(window as unknown as { Capacitor?: { isNativePlatform?: () => boolean } }).Capacitor?.isNativePlatform?.();
  const [isRunning, setIsRunning] = useState(false);

  // Sync initial state from native layer when running as APK
  useEffect(() => {
    if (!isNative) return;
    getPlugin()
      ?.getStatus()
      .then(({ enabled }) => setIsRunning(enabled))
      .catch(() => {});
  }, [isNative]);

  const start = useCallback(async (threshold: number, frequency: number) => {
    const plugin = getPlugin();
    if (plugin) {
      await plugin.startMonitor({ threshold, frequency });
    }
    setIsRunning(true);
  }, []);

  const stop = useCallback(async () => {
    const plugin = getPlugin();
    if (plugin) {
      await plugin.stopMonitor();
    }
    setIsRunning(false);
  }, []);

  return { isNative, isRunning, start, stop };
}
