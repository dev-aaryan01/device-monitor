import { useCallback, useEffect, useState } from "react";

export interface AudioOutputDevice {
  deviceId: string;
  label: string;
  isBluetooth: boolean;
}

interface AudioOutputDevicesState {
  devices: AudioOutputDevice[];
  selectedId: string;
  setSelectedId: (id: string) => void;
  refresh: () => Promise<void>;
  permissionGranted: boolean;
  requestPermission: () => Promise<void>;
  isSupported: boolean;
}

const BLUETOOTH_KEYWORDS = ["bluetooth", "btle", "tws", "wireless", "airpods", "galaxy buds", "earbuds", "headset", "headphones", "a2dp", "hands-free"];

function classifyDevice(label: string): boolean {
  const lower = label.toLowerCase();
  return BLUETOOTH_KEYWORDS.some((kw) => lower.includes(kw));
}

export function useAudioOutputDevices(): AudioOutputDevicesState {
  const [devices, setDevices] = useState<AudioOutputDevice[]>([]);
  const [selectedId, setSelectedId] = useState<string>("default");
  const [permissionGranted, setPermissionGranted] = useState(false);
  const isSupported =
    typeof navigator.mediaDevices?.enumerateDevices === "function" &&
    typeof HTMLAudioElement.prototype.setSinkId === "function";

  const refresh = useCallback(async () => {
    if (!isSupported) return;
    try {
      const raw = await navigator.mediaDevices.enumerateDevices();
      const outputs = raw
        .filter((d) => d.kind === "audiooutput")
        .map((d) => ({
          deviceId: d.deviceId,
          label: d.label || (d.deviceId === "default" ? "Default (System)" : `Output device ${d.deviceId.slice(0, 6)}`),
          isBluetooth: classifyDevice(d.label),
        }));
      setDevices(outputs);
      const hasLabels = outputs.some((d) => d.label && !d.label.startsWith("Output device"));
      setPermissionGranted(hasLabels || outputs.length > 0);
    } catch (err) {
      console.warn("[AudioOutputDevices] enumerate failed:", err);
    }
  }, [isSupported]);

  const requestPermission = useCallback(async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      stream.getTracks().forEach((t) => t.stop());
      setPermissionGranted(true);
      await refresh();
    } catch (err) {
      console.warn("[AudioOutputDevices] Permission denied:", err);
    }
  }, [refresh]);

  useEffect(() => {
    if (!isSupported) return;
    refresh();
    navigator.mediaDevices.addEventListener("devicechange", refresh);
    return () => navigator.mediaDevices.removeEventListener("devicechange", refresh);
  }, [isSupported, refresh]);

  return { devices, selectedId, setSelectedId, refresh, permissionGranted, requestPermission, isSupported };
}
