import { useEffect, useState } from "react";

interface BatteryState {
  percentage: number;
  isCharging: boolean;
  timeToFull: number | null;
  timeToEmpty: number | null;
  supported: boolean;
}

interface BatteryManager extends EventTarget {
  level: number;
  charging: boolean;
  chargingTime: number;
  dischargingTime: number;
}

declare global {
  interface Navigator {
    getBattery?: () => Promise<BatteryManager>;
  }
}

export function useBattery(): BatteryState {
  const [state, setState] = useState<BatteryState>({
    percentage: 72,
    isCharging: false,
    timeToFull: null,
    timeToEmpty: null,
    supported: false,
  });

  useEffect(() => {
    if (!navigator.getBattery) return;

    let battery: BatteryManager | null = null;

    const update = () => {
      if (!battery) return;
      setState({
        percentage: Math.round(battery.level * 100),
        isCharging: battery.charging,
        timeToFull: battery.chargingTime === Infinity ? null : battery.chargingTime,
        timeToEmpty: battery.dischargingTime === Infinity ? null : battery.dischargingTime,
        supported: true,
      });
    };

    navigator.getBattery().then((b) => {
      battery = b;
      update();
      b.addEventListener("levelchange", update);
      b.addEventListener("chargingchange", update);
    });

    return () => {
      if (battery) {
        battery.removeEventListener("levelchange", update);
        battery.removeEventListener("chargingchange", update);
      }
    };
  }, []);

  return state;
}
