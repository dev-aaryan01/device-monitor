import { useCallback, useEffect, useRef, useState } from "react";

interface AudioSignalOptions {
  frequency?: number;
  volume?: number;
}

export type SignalState = "idle" | "active" | "done";

interface AudioSignalState {
  signalState: SignalState;
  isSupported: boolean;
  sinkId: string;
  setSinkId: (id: string) => void;
  playOnce: (durationMs?: number) => void;   // one-shot beep
  start: () => void;                          // manual test (continuous)
  stop: () => void;
  toggle: () => void;
  isActive: boolean;
}

export function useAudioSignal({
  frequency = 1800,
  volume = 0.8,
}: AudioSignalOptions = {}): AudioSignalState {
  const [signalState, setSignalState] = useState<SignalState>("idle");
  const [sinkId, setSinkIdState] = useState<string>("default");

  const ctxRef    = useRef<AudioContext | null>(null);
  const oscRef    = useRef<OscillatorNode | null>(null);
  const gainRef   = useRef<GainNode | null>(null);
  const destRef   = useRef<MediaStreamAudioDestinationNode | null>(null);
  const audioElRef= useRef<HTMLAudioElement | null>(null);
  const timerRef  = useRef<ReturnType<typeof setTimeout> | null>(null);

  const isSupported =
    typeof AudioContext !== "undefined" ||
    typeof (window as unknown as { webkitAudioContext: unknown }).webkitAudioContext !== "undefined";

  const setSinkId = useCallback(async (id: string) => {
    setSinkIdState(id);
    if (audioElRef.current && typeof audioElRef.current.setSinkId === "function") {
      try { await audioElRef.current.setSinkId(id); } catch (e) {
        console.warn("[AudioSignal] setSinkId failed:", e);
      }
    }
  }, []);

  const stop = useCallback(() => {
    if (timerRef.current) { clearTimeout(timerRef.current); timerRef.current = null; }
    if (gainRef.current && ctxRef.current) {
      const gain = gainRef.current;
      const ctx  = ctxRef.current;
      gain.gain.setTargetAtTime(0, ctx.currentTime, 0.05);
      setTimeout(() => {
        try { oscRef.current?.stop(); } catch {}
        oscRef.current?.disconnect();
        gainRef.current?.disconnect();
        destRef.current?.disconnect();
        oscRef.current = gainRef.current = destRef.current = null;
        if (audioElRef.current) { audioElRef.current.pause(); audioElRef.current.srcObject = null; }
      }, 200);
    }
    setSignalState("idle");
  }, []);

  const startRaw = useCallback(async () => {
    try {
      const WA =
        (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext ?? AudioContext;
      if (!ctxRef.current || ctxRef.current.state === "closed") ctxRef.current = new WA();
      const ctx = ctxRef.current;
      if (ctx.state === "suspended") await ctx.resume();

      try { oscRef.current?.stop(); } catch {}
      oscRef.current?.disconnect();
      gainRef.current?.disconnect();
      destRef.current?.disconnect();

      const osc  = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = "sine";
      osc.frequency.setValueAtTime(frequency, ctx.currentTime);
      gain.gain.setValueAtTime(0, ctx.currentTime);
      gain.gain.setTargetAtTime(volume, ctx.currentTime, 0.08);

      const supportsSink = typeof HTMLAudioElement.prototype.setSinkId === "function";

      if (supportsSink && sinkId !== "default") {
        const dest = ctx.createMediaStreamDestination();
        osc.connect(gain);
        gain.connect(dest);
        if (!audioElRef.current) { audioElRef.current = new Audio(); audioElRef.current.autoplay = true; }
        try { await audioElRef.current.setSinkId(sinkId); } catch {}
        audioElRef.current.srcObject = dest.stream;
        await audioElRef.current.play().catch(() => {});
        destRef.current = dest;
      } else {
        osc.connect(gain);
        gain.connect(ctx.destination);
      }

      osc.start();
      oscRef.current  = osc;
      gainRef.current = gain;
    } catch (err) {
      console.error("[AudioSignal] start failed:", err);
    }
  }, [frequency, volume, sinkId]);

  /** One-shot: beep for durationMs then auto-stop, shows "done" state */
  const playOnce = useCallback((durationMs = 5000) => {
    startRaw().then(() => {
      setSignalState("active");
      if (timerRef.current) clearTimeout(timerRef.current);
      timerRef.current = setTimeout(() => {
        stop();
        setSignalState("done");
        // Reset "done" badge after 4 s
        setTimeout(() => setSignalState("idle"), 4000);
      }, durationMs);
    });
  }, [startRaw, stop]);

  const start = useCallback(() => {
    startRaw().then(() => setSignalState("active"));
  }, [startRaw]);

  const toggle = useCallback(() => {
    if (signalState === "active") stop();
    else start();
  }, [signalState, start, stop]);

  useEffect(() => () => {
    timerRef.current && clearTimeout(timerRef.current);
    try { oscRef.current?.stop(); } catch {}
    oscRef.current?.disconnect();
    gainRef.current?.disconnect();
    destRef.current?.disconnect();
    ctxRef.current?.close();
    if (audioElRef.current) { audioElRef.current.pause(); audioElRef.current.srcObject = null; }
  }, []);

  return {
    signalState,
    isActive: signalState === "active",
    isSupported,
    sinkId,
    setSinkId,
    playOnce,
    start,
    stop,
    toggle,
  };
}
