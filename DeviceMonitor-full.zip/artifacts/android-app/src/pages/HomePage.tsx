import { useEffect, useState } from "react";
import { BatteryCircle } from "@/components/BatteryCircle";
import { BatteryOptimizationModal } from "@/components/BatteryOptimizationModal";
import { BatteryCutoffSlider } from "@/components/BatteryCutoffSlider";
import { BluetoothAudioSelector } from "@/components/BluetoothAudioSelector";
import { GlassCard } from "@/components/GlassCard";
import { MasterToggle } from "@/components/MasterToggle";
import { StatusBadge } from "@/components/StatusBadge";
import { useBattery } from "@/hooks/useBattery";
import { useAudioSignal } from "@/hooks/useAudioSignal";
import { useAudioOutputDevices } from "@/hooks/useAudioOutputDevices";
import { useForegroundService } from "@/hooks/useForegroundService";

export default function HomePage() {
  const battery      = useBattery();
  const outputDevs   = useAudioOutputDevices();
  const audio        = useAudioSignal({ frequency: 1800, volume: 0.85 });
  const foreground   = useForegroundService();

  const [masterEnabled, setMasterEnabled]   = useState(true);
  const [modalOpen, setModalOpen]           = useState(false);
  const [optDismissed, setOptDismissed]     = useState(false);
  const [settingsToast, setSettingsToast]   = useState(false);
  const [threshold, setThreshold]           = useState(90);
  const [firedOnce, setFiredOnce]           = useState(false);   // one-shot guard

  // ── Sync output device into audio hook ────────────────────────────────────
  useEffect(() => {
    if (outputDevs.selectedId !== audio.sinkId) audio.setSinkId(outputDevs.selectedId);
  }, [outputDevs.selectedId, audio]);

  // ── One-shot auto-trigger (web layer) ─────────────────────────────────────
  useEffect(() => {
    if (!masterEnabled || firedOnce) return;
    if (battery.percentage >= threshold) {
      setFiredOnce(true);
      audio.playOnce(5000);          // 5-second beep, then auto-stops
    }
  }, [masterEnabled, firedOnce, battery.percentage, threshold, audio]);

  // ── Reset firedOnce when threshold changes so it can fire again ──────────
  useEffect(() => { setFiredOnce(false); }, [threshold]);

  // ── Master toggle ─────────────────────────────────────────────────────────
  function handleMasterToggle() {
    const next = !masterEnabled;
    setMasterEnabled(next);
    if (!next) {
      foreground.stop().catch(console.warn);
      audio.stop();
      setFiredOnce(false);
    } else {
      foreground.start(threshold, 1800).catch(console.warn);
    }
  }

  // ── Keep native service threshold in sync ────────────────────────────────
  useEffect(() => {
    if (masterEnabled && foreground.isNative) foreground.start(threshold, 1800).catch(console.warn);
  }, [threshold]);   // eslint-disable-line react-hooks/exhaustive-deps

  function handleGoToSettings() {
    setSettingsToast(true); setModalOpen(false);
    setTimeout(() => setSettingsToast(false), 3000);
  }

  function handleTestBeep() {
    if (!masterEnabled) return;
    if (audio.isActive) { audio.stop(); return; }
    audio.playOnce(5000);
  }

  const { signalState } = audio;

  return (
    <div
      className="min-h-dvh flex flex-col items-center px-4 py-8 gap-5 max-w-sm mx-auto transition-opacity duration-500"
      style={{ opacity: masterEnabled ? 1 : 0.58 }}
    >
      {/* ─── Header ───────────────────────────────────────────────────── */}
      <header className="w-full flex items-center justify-between">
        <div>
          <p className="text-xs text-white/30 tracking-widest uppercase font-medium mb-0.5">Android Manager</p>
          <h1 className="text-lg font-bold text-white leading-tight">Device Monitor</h1>
        </div>
        <MasterToggle enabled={masterEnabled} onToggle={handleMasterToggle} />
      </header>

      {/* ─── Sleep banner ────────────────────────────────────────────── */}
      {!masterEnabled && (
        <div className="w-full flex items-center gap-3 px-4 py-3 rounded-2xl"
          style={{ background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.08)" }}>
          <div className="w-8 h-8 rounded-xl flex items-center justify-center flex-shrink-0"
            style={{ background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.08)" }}>
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none">
              <path d="M21 12.79A9 9 0 1111.21 3 7 7 0 0021 12.79z" stroke="rgba(255,255,255,0.4)" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          </div>
          <div>
            <p className="text-sm font-semibold text-white/60">Monitoring paused</p>
            <p className="text-xs text-white/30">Toggle ON to start battery watch</p>
          </div>
        </div>
      )}

      {/* ─── Battery card ────────────────────────────────────────────── */}
      <GlassCard gradientBorder className="w-full p-6 flex flex-col items-center gap-5">
        <div className="w-full flex items-center justify-between">
          <span className="text-sm font-semibold text-white/80">Battery Status</span>
          <SignalStatusBadge
            signalState={signalState}
            masterEnabled={masterEnabled}
            batteryPct={battery.percentage}
          />
        </div>

        <div className={masterEnabled ? "animate-float" : ""}>
          <BatteryCircle percentage={battery.percentage} isCharging={battery.isCharging} size={190} />
        </div>

        {/* 3 stat tiles */}
        <div className="w-full grid grid-cols-3 gap-3">
          <StatTile label="Health" value="Good" color="#39ff14"
            icon={<path d="M20.84 4.61a5.5 5.5 0 00-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 00-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 000-7.78z" stroke="#39ff14" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />}
          />
          <StatTile
            label={battery.isCharging ? "Charging" : "Idle"}
            value={battery.isCharging ? "On" : "Off"}
            color={battery.isCharging ? "#00f5ff" : "#bf5af2"}
            icon={<>
              <path d="M5 12h14" stroke={battery.isCharging ? "#00f5ff" : "#bf5af2"} strokeWidth="1.5" strokeLinecap="round" />
              <path d="M13 6l6 6-6 6" stroke={battery.isCharging ? "#00f5ff" : "#bf5af2"} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
            </>}
          />
          <StatTile
            label="Signal"
            value={signalState === "active" ? "Beeping" : signalState === "done" ? "Done ✓" : "Ready"}
            color={signalState === "active" ? "#ff3b30" : signalState === "done" ? "#39ff14" : "#ff9f0a"}
            icon={<path d="M12 2L2 20h20L12 2z" stroke={signalState === "active" ? "#ff3b30" : signalState === "done" ? "#39ff14" : "#ff9f0a"} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />}
          />
        </div>

        {/* Slider — 50 to 100 */}
        <BatteryCutoffSlider
          value={threshold}
          onChange={(v) => { setThreshold(v); setFiredOnce(false); }}
          min={50}
          max={100}
          currentBattery={battery.percentage}
        />
      </GlassCard>

      {/* ─── Done state card ──────────────────────────────────────────── */}
      {signalState === "done" && (
        <div className="w-full flex items-center gap-3 px-4 py-3.5 rounded-2xl animate-modal-in"
          style={{ background: "rgba(57,255,20,0.06)", border: "1px solid rgba(57,255,20,0.2)" }}>
          <span className="text-xl">✅</span>
          <div>
            <p className="text-sm font-semibold" style={{ color: "rgba(57,255,20,0.9)" }}>Beep sent successfully</p>
            <p className="text-xs text-white/40">5-second signal delivered to Bluetooth device</p>
          </div>
        </div>
      )}

      {/* ─── Active beep countdown card ──────────────────────────────── */}
      {signalState === "active" && (
        <div className="w-full flex items-center gap-3 px-4 py-3.5 rounded-2xl animate-modal-in"
          style={{ background: "rgba(255,59,48,0.08)", border: "1px solid rgba(255,59,48,0.25)", boxShadow: "0 0 20px rgba(255,59,48,0.1)" }}>
          <span className="w-3 h-3 rounded-full flex-shrink-0 animate-pulse" style={{ background: "#ff3b30", boxShadow: "0 0 8px #ff3b30" }} />
          <div>
            <p className="text-sm font-semibold" style={{ color: "#ff3b30" }}>⚡ Beeping to Bluetooth — 5 sec</p>
            <p className="text-xs text-white/40">Service will stop automatically after signal</p>
          </div>
        </div>
      )}

      {/* ─── Bluetooth selector ───────────────────────────────────────── */}
      <BluetoothAudioSelector
        devices={outputDevs.devices}
        selectedId={outputDevs.selectedId}
        onSelect={outputDevs.setSelectedId}
        onRequestPermission={outputDevs.requestPermission}
        permissionGranted={outputDevs.permissionGranted}
        isSupported={outputDevs.isSupported}
        isSignalActive={signalState === "active"}
      />

      {/* ─── Test button ─────────────────────────────────────────────── */}
      <button
        onClick={handleTestBeep}
        disabled={!masterEnabled || signalState === "done"}
        className="w-full relative flex items-center justify-center gap-3 py-4 px-6 rounded-2xl font-semibold text-sm transition-all duration-200 active:scale-[0.97] overflow-hidden disabled:opacity-40 disabled:pointer-events-none"
        style={
          signalState === "active"
            ? { background: "rgba(255,59,48,0.14)", border: "1px solid rgba(255,59,48,0.4)", color: "#ff3b30", boxShadow: "0 0 24px rgba(255,59,48,0.2)" }
            : { background: "linear-gradient(135deg, rgba(0,245,255,0.12), rgba(191,90,242,0.12))", border: "1px solid rgba(0,245,255,0.3)", color: "#00f5ff", boxShadow: "0 0 20px rgba(0,245,255,0.12)" }
        }
      >
        {signalState === "active" ? (
          <>
            <span className="w-3 h-3 rounded-full animate-pulse" style={{ background: "#ff3b30", boxShadow: "0 0 8px #ff3b30" }} />
            <span style={{ textShadow: "0 0 12px rgba(255,59,48,0.6)" }}>Beeping… (tap to stop)</span>
          </>
        ) : (
          <>
            <svg width="17" height="17" viewBox="0 0 24 24" fill="none">
              <path d="M11 5L6 9H2v6h4l5 4V5z" stroke="#00f5ff" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
              <path d="M19.07 4.93a10 10 0 010 14.14M15.54 8.46a5 5 0 010 7.07" stroke="#00f5ff" strokeWidth="1.5" strokeLinecap="round" />
            </svg>
            <span style={{ textShadow: "0 0 12px rgba(0,245,255,0.5)" }}>
              Test Signal (5 sec beep)
            </span>
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" className="ml-auto">
              <polygon points="5,3 19,12 5,21" fill="#00f5ff" opacity="0.8" />
            </svg>
          </>
        )}
      </button>

      {/* ─── Native service info ──────────────────────────────────────── */}
      {foreground.isNative && masterEnabled && (
        <div className="w-full flex items-center gap-3 px-4 py-3 rounded-2xl"
          style={{ background: "rgba(57,255,20,0.05)", border: "1px solid rgba(57,255,20,0.12)" }}>
          <span className="w-2 h-2 rounded-full flex-shrink-0 animate-pulse-neon" style={{ background: "#39ff14", boxShadow: "0 0 6px #39ff14" }} />
          <p className="text-xs" style={{ color: "rgba(57,255,20,0.8)" }}>
            Foreground service active — monitoring with screen off
          </p>
        </div>
      )}

      {/* ─── Battery optimization banner ──────────────────────────────── */}
      {!optDismissed && (
        <GlassCard className="w-full" glowColor="rgba(255,159,10,1)">
          <div className="p-4 flex items-start gap-3">
            <div className="w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0 animate-pulse-neon"
              style={{ background: "rgba(255,159,10,0.12)", border: "1px solid rgba(255,159,10,0.25)" }}>
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none">
                <path d="M12 2L2 20h20L12 2z" stroke="#ff9f0a" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
                <path d="M12 9v5" stroke="#ff9f0a" strokeWidth="1.5" strokeLinecap="round" />
                <circle cx="12" cy="17" r="0.5" fill="#ff9f0a" stroke="#ff9f0a" strokeWidth="1" />
              </svg>
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-semibold text-white mb-0.5">Battery optimization active</p>
              <p className="text-xs text-white/45">Disable to prevent Android killing this service</p>
            </div>
          </div>
          <div className="px-4 pb-4 flex gap-2">
            <button onClick={() => setModalOpen(true)}
              className="flex-1 py-2.5 rounded-xl text-sm font-semibold transition-all duration-200 active:scale-[0.97]"
              style={{ background: "linear-gradient(135deg, rgba(0,245,255,0.12), rgba(191,90,242,0.12))", border: "1px solid rgba(0,245,255,0.25)", color: "#00f5ff" }}>
              Fix This
            </button>
            <button onClick={() => setOptDismissed(true)}
              className="px-4 py-2.5 rounded-xl text-sm font-medium text-white/35 transition-all duration-200 active:scale-[0.97]"
              style={{ background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.07)" }}>
              Dismiss
            </button>
          </div>
        </GlassCard>
      )}

      {/* ─── Toast ───────────────────────────────────────────────────── */}
      {settingsToast && (
        <div className="fixed bottom-6 left-4 right-4 max-w-sm mx-auto py-3.5 px-5 rounded-2xl flex items-center gap-3 animate-modal-in"
          style={{ background: "rgba(12,14,22,0.95)", border: "1px solid rgba(0,245,255,0.25)", backdropFilter: "blur(20px)", boxShadow: "0 0 30px rgba(0,245,255,0.15)" }}>
          <span className="text-lg">⚡</span>
          <div>
            <p className="text-sm font-semibold text-white">Opening Battery Settings</p>
            <p className="text-xs text-white/45">Apps → Special Access → Battery Optimization</p>
          </div>
        </div>
      )}

      <BatteryOptimizationModal open={modalOpen} onClose={() => setModalOpen(false)} onGoToSettings={handleGoToSettings} />
    </div>
  );
}

// ── Sub-components ─────────────────────────────────────────────────────────────

function SignalStatusBadge({ signalState, masterEnabled, batteryPct }: {
  signalState: "idle" | "active" | "done";
  masterEnabled: boolean;
  batteryPct: number;
}) {
  if (!masterEnabled) return <StatusBadge label="Status" value="Paused" color="purple" />;
  if (signalState === "active") return (
    <div className="flex items-center gap-2 px-3 py-2 rounded-xl"
      style={{ background: "rgba(255,59,48,0.1)", border: "1px solid rgba(255,59,48,0.3)", boxShadow: "0 0 16px rgba(255,59,48,0.2)" }}>
      <span className="w-2 h-2 rounded-full animate-pulse" style={{ background: "#ff3b30", boxShadow: "0 0 6px #ff3b30" }} />
      <span className="text-xs font-semibold" style={{ color: "#ff3b30" }}>Signal Transmitting...</span>
    </div>
  );
  if (signalState === "done") return (
    <div className="flex items-center gap-2 px-3 py-2 rounded-xl"
      style={{ background: "rgba(57,255,20,0.08)", border: "1px solid rgba(57,255,20,0.25)" }}>
      <span className="text-xs">✅</span>
      <span className="text-xs font-semibold" style={{ color: "#39ff14" }}>Beep Sent</span>
    </div>
  );
  return (
    <StatusBadge
      label="Level"
      value={batteryPct > 60 ? "Healthy" : batteryPct > 20 ? "Normal" : "Low"}
      color={batteryPct > 60 ? "green" : batteryPct > 20 ? "cyan" : "orange"}
    />
  );
}

function StatTile({ label, value, color, icon }: {
  label: string; value: string; color: string; icon: React.ReactNode;
}) {
  return (
    <div className="flex flex-col items-center gap-1.5 py-3 rounded-xl transition-all duration-300"
      style={{ background: `${color}10`, border: `1px solid ${color}20` }}>
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none">{icon}</svg>
      <span className="text-sm font-bold text-white">{value}</span>
      <span className="text-xs text-white/35">{label}</span>
    </div>
  );
}
