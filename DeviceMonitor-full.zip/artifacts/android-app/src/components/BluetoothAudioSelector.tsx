import { AudioOutputDevice } from "@/hooks/useAudioOutputDevices";

interface BluetoothAudioSelectorProps {
  devices: AudioOutputDevice[];
  selectedId: string;
  onSelect: (id: string) => void;
  onRequestPermission: () => void;
  permissionGranted: boolean;
  isSupported: boolean;
  isSignalActive: boolean;
}

export function BluetoothAudioSelector({
  devices,
  selectedId,
  onSelect,
  onRequestPermission,
  permissionGranted,
  isSupported,
  isSignalActive,
}: BluetoothAudioSelectorProps) {
  if (!isSupported) {
    return (
      <div
        className="w-full rounded-2xl p-4 flex items-start gap-3"
        style={{
          background: "rgba(255,159,10,0.06)",
          border: "1px solid rgba(255,159,10,0.15)",
        }}
      >
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" className="flex-shrink-0 mt-0.5">
          <path d="M12 2L2 20h20L12 2z" stroke="#ff9f0a" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
          <path d="M12 9v5" stroke="#ff9f0a" strokeWidth="1.5" strokeLinecap="round" />
          <circle cx="12" cy="17" r="0.5" fill="#ff9f0a" stroke="#ff9f0a" strokeWidth="1" />
        </svg>
        <div>
          <p className="text-sm font-semibold text-white/80">Output routing unavailable</p>
          <p className="text-xs text-white/40 mt-0.5 leading-relaxed">
            Your browser doesn't support audio device selection. Use Chrome on Android for Bluetooth routing.
          </p>
        </div>
      </div>
    );
  }

  if (!permissionGranted || devices.length === 0) {
    return (
      <div
        className="w-full rounded-2xl p-4"
        style={{
          background: "rgba(0,245,255,0.04)",
          border: "1px solid rgba(0,245,255,0.1)",
        }}
      >
        <div className="flex items-center gap-3 mb-3">
          <BluetoothIcon color="#00f5ff" />
          <div>
            <p className="text-sm font-semibold text-white">Bluetooth Audio Routing</p>
            <p className="text-xs text-white/40 mt-0.5">Route signal only to your TWS device</p>
          </div>
        </div>
        <button
          onClick={onRequestPermission}
          className="w-full py-2.5 rounded-xl text-sm font-semibold transition-all duration-200 active:scale-[0.97]"
          style={{
            background: "linear-gradient(135deg, rgba(0,245,255,0.12) 0%, rgba(191,90,242,0.12) 100%)",
            border: "1px solid rgba(0,245,255,0.25)",
            color: "#00f5ff",
          }}
        >
          Grant microphone access to detect devices
        </button>
        <p className="text-xs text-white/25 text-center mt-2">
          Microphone permission is required to enumerate audio output devices
        </p>
      </div>
    );
  }

  const bluetoothDevices = devices.filter((d) => d.isBluetooth);
  const otherDevices = devices.filter((d) => !d.isBluetooth);
  const selected = devices.find((d) => d.deviceId === selectedId);

  return (
    <div
      className="w-full rounded-2xl p-5"
      style={{
        background: "rgba(255,255,255,0.03)",
        border: "1px solid rgba(255,255,255,0.08)",
      }}
    >
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2.5">
          <BluetoothIcon color={isSignalActive ? "#ff3b30" : "#00f5ff"} />
          <div>
            <p className="text-sm font-semibold text-white">Audio Output Routing</p>
            <p className="text-xs text-white/40 mt-0.5">Signal-only device</p>
          </div>
        </div>
        {selected && (
          <div
            className="px-2 py-1 rounded-lg text-xs font-medium"
            style={{
              background: selected.isBluetooth ? "rgba(0,245,255,0.08)" : "rgba(255,255,255,0.06)",
              border: `1px solid ${selected.isBluetooth ? "rgba(0,245,255,0.2)" : "rgba(255,255,255,0.1)"}`,
              color: selected.isBluetooth ? "#00f5ff" : "rgba(255,255,255,0.5)",
            }}
          >
            {selected.isBluetooth ? "BT" : "SYS"}
          </div>
        )}
      </div>

      <div className="space-y-1.5">
        {bluetoothDevices.length > 0 && (
          <>
            <p className="text-xs text-white/30 uppercase tracking-widest font-medium px-1 mb-2">
              Bluetooth Devices
            </p>
            {bluetoothDevices.map((device) => (
              <DeviceRow
                key={device.deviceId}
                device={device}
                isSelected={selectedId === device.deviceId}
                onSelect={onSelect}
                isSignalActive={isSignalActive}
              />
            ))}
          </>
        )}

        {bluetoothDevices.length === 0 && (
          <div
            className="flex items-center gap-2.5 px-3 py-2.5 rounded-xl mb-2"
            style={{
              background: "rgba(255,159,10,0.06)",
              border: "1px solid rgba(255,159,10,0.12)",
            }}
          >
            <span className="text-sm">🔍</span>
            <p className="text-xs text-white/45">No Bluetooth devices detected — connect your TWS first</p>
          </div>
        )}

        {otherDevices.length > 0 && (
          <>
            <p className="text-xs text-white/30 uppercase tracking-widest font-medium px-1 mt-3 mb-2">
              Other Outputs
            </p>
            {otherDevices.map((device) => (
              <DeviceRow
                key={device.deviceId}
                device={device}
                isSelected={selectedId === device.deviceId}
                onSelect={onSelect}
                isSignalActive={isSignalActive}
              />
            ))}
          </>
        )}
      </div>

      {selected && !selected.isBluetooth && selectedId !== "default" && (
        <div
          className="mt-3 flex items-start gap-2 px-3 py-2.5 rounded-xl"
          style={{
            background: "rgba(255,159,10,0.06)",
            border: "1px solid rgba(255,159,10,0.15)",
          }}
        >
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" className="flex-shrink-0 mt-0.5">
            <path d="M12 2L2 20h20L12 2z" stroke="#ff9f0a" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
            <path d="M12 9v5" stroke="#ff9f0a" strokeWidth="1.5" strokeLinecap="round" />
          </svg>
          <p className="text-xs leading-relaxed" style={{ color: "rgba(255,159,10,0.8)" }}>
            Non-Bluetooth output selected. Phone calls and system sounds share this device.
          </p>
        </div>
      )}

      {selected?.isBluetooth && (
        <div
          className="mt-3 flex items-center gap-2 px-3 py-2 rounded-xl"
          style={{
            background: "rgba(57,255,20,0.06)",
            border: "1px solid rgba(57,255,20,0.12)",
          }}
        >
          <span
            className="w-2 h-2 rounded-full flex-shrink-0"
            style={{ background: "#39ff14", boxShadow: "0 0 6px #39ff14" }}
          />
          <p className="text-xs" style={{ color: "rgba(57,255,20,0.8)" }}>
            Signal will route exclusively to Bluetooth — system audio unaffected
          </p>
        </div>
      )}
    </div>
  );
}

function DeviceRow({
  device,
  isSelected,
  onSelect,
  isSignalActive,
}: {
  device: AudioOutputDevice;
  isSelected: boolean;
  onSelect: (id: string) => void;
  isSignalActive: boolean;
}) {
  return (
    <button
      onClick={() => onSelect(device.deviceId)}
      className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-left transition-all duration-150 active:scale-[0.98]"
      style={{
        background: isSelected
          ? device.isBluetooth
            ? "rgba(0,245,255,0.08)"
            : "rgba(255,255,255,0.06)"
          : "rgba(255,255,255,0.02)",
        border: isSelected
          ? `1px solid ${device.isBluetooth ? "rgba(0,245,255,0.25)" : "rgba(255,255,255,0.12)"}`
          : "1px solid rgba(255,255,255,0.04)",
      }}
    >
      <div
        className="w-8 h-8 rounded-xl flex items-center justify-center flex-shrink-0"
        style={{
          background: device.isBluetooth ? "rgba(0,245,255,0.08)" : "rgba(255,255,255,0.05)",
        }}
      >
        {device.isBluetooth ? (
          <BluetoothIcon color={isSelected && isSignalActive ? "#ff3b30" : "#00f5ff"} size={14} />
        ) : (
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none">
            <path d="M11 5L6 9H2v6h4l5 4V5zM19.07 4.93a10 10 0 010 14.14M15.54 8.46a5 5 0 010 7.07" stroke="rgba(255,255,255,0.4)" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        )}
      </div>

      <div className="flex-1 min-w-0">
        <p className="text-sm font-medium text-white truncate">{device.label}</p>
        <p className="text-xs text-white/35">{device.isBluetooth ? "Bluetooth" : "System output"}</p>
      </div>

      {isSelected && (
        <div
          className="w-5 h-5 rounded-full flex items-center justify-center flex-shrink-0"
          style={{
            background: device.isBluetooth ? "rgba(0,245,255,0.2)" : "rgba(255,255,255,0.1)",
          }}
        >
          <svg width="10" height="10" viewBox="0 0 12 12" fill="none">
            <path d="M2 6l3 3 5-5" stroke={device.isBluetooth ? "#00f5ff" : "rgba(255,255,255,0.6)"} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        </div>
      )}
    </button>
  );
}

function BluetoothIcon({ color = "#00f5ff", size = 18 }: { color?: string; size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none">
      <path d="M6.5 6.5l11 11L12 23V1l5.5 5.5-11 11" stroke={color} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}
