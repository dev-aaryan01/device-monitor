interface MasterToggleProps {
  enabled: boolean;
  onToggle: () => void;
}

export function MasterToggle({ enabled, onToggle }: MasterToggleProps) {
  return (
    <button
      onClick={onToggle}
      aria-label={enabled ? "Turn monitoring off" : "Turn monitoring on"}
      className="relative flex items-center gap-2 rounded-2xl px-3 py-1.5 transition-all duration-300 active:scale-95 select-none"
      style={{
        background: enabled
          ? "rgba(0,245,255,0.08)"
          : "rgba(255,255,255,0.04)",
        border: enabled
          ? "1px solid rgba(0,245,255,0.25)"
          : "1px solid rgba(255,255,255,0.1)",
        boxShadow: enabled
          ? "0 0 18px rgba(0,245,255,0.15), inset 0 1px 0 rgba(255,255,255,0.06)"
          : "inset 0 1px 0 rgba(255,255,255,0.04)",
      }}
    >
      {/* Track */}
      <div
        className="relative w-10 h-5.5 rounded-full transition-all duration-300 flex-shrink-0"
        style={{
          width: 40,
          height: 22,
          background: enabled
            ? "linear-gradient(90deg, rgba(0,245,255,0.4), rgba(0,245,255,0.25))"
            : "rgba(255,255,255,0.08)",
          border: enabled
            ? "1px solid rgba(0,245,255,0.4)"
            : "1px solid rgba(255,255,255,0.12)",
          boxShadow: enabled ? "0 0 10px rgba(0,245,255,0.3)" : "none",
        }}
      >
        {/* Thumb */}
        <div
          className="absolute top-0.5 rounded-full transition-all duration-300"
          style={{
            width: 18,
            height: 18,
            left: enabled ? 20 : 2,
            background: enabled ? "#00f5ff" : "rgba(255,255,255,0.35)",
            boxShadow: enabled
              ? "0 0 8px rgba(0,245,255,0.8), 0 1px 4px rgba(0,0,0,0.4)"
              : "0 1px 3px rgba(0,0,0,0.3)",
          }}
        />
      </div>

      {/* Label */}
      <span
        className="text-xs font-semibold tracking-wide transition-all duration-300"
        style={{
          color: enabled ? "#00f5ff" : "rgba(255,255,255,0.35)",
          textShadow: enabled ? "0 0 8px rgba(0,245,255,0.5)" : "none",
          minWidth: 24,
        }}
      >
        {enabled ? "ON" : "OFF"}
      </span>
    </button>
  );
}
