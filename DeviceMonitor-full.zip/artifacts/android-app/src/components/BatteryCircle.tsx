import { useEffect, useRef, useState } from "react";

interface BatteryCircleProps {
  percentage: number;
  isCharging?: boolean;
  size?: number;
}

function getBatteryColor(pct: number) {
  if (pct > 60) return { stroke: "#39ff14", glow: "rgba(57,255,20,0.5)", text: "neon-text-green" };
  if (pct > 20) return { stroke: "#00f5ff", glow: "rgba(0,245,255,0.5)", text: "neon-text-cyan" };
  return { stroke: "#ff9f0a", glow: "rgba(255,159,10,0.5)", text: "neon-text-orange" };
}

export function BatteryCircle({ percentage, isCharging = false, size = 200 }: BatteryCircleProps) {
  const [animated, setAnimated] = useState(0);
  const animRef = useRef<number | null>(null);

  useEffect(() => {
    let start: number | null = null;
    const duration = 1400;
    const from = 0;
    const to = percentage;

    const step = (ts: number) => {
      if (!start) start = ts;
      const progress = Math.min((ts - start) / duration, 1);
      const ease = 1 - Math.pow(1 - progress, 3);
      setAnimated(Math.round(from + (to - from) * ease));
      if (progress < 1) animRef.current = requestAnimationFrame(step);
    };
    animRef.current = requestAnimationFrame(step);
    return () => { if (animRef.current) cancelAnimationFrame(animRef.current); };
  }, [percentage]);

  const radius = size * 0.38;
  const stroke = size * 0.055;
  const cx = size / 2;
  const cy = size / 2;
  const circumference = 2 * Math.PI * radius;
  const dashOffset = circumference - (animated / 100) * circumference;
  const colors = getBatteryColor(percentage);

  return (
    <div className="relative flex items-center justify-center" style={{ width: size, height: size }}>
      <svg
        width={size}
        height={size}
        viewBox={`0 0 ${size} ${size}`}
        style={{ position: "absolute", top: 0, left: 0 }}
      >
        <defs>
          <filter id="glow" x="-50%" y="-50%" width="200%" height="200%">
            <feGaussianBlur stdDeviation="4" result="blur" />
            <feMerge>
              <feMergeNode in="blur" />
              <feMergeNode in="SourceGraphic" />
            </feMerge>
          </filter>
          <linearGradient id="arcGradient" x1="0%" y1="0%" x2="100%" y2="0%">
            <stop offset="0%" stopColor={colors.stroke} stopOpacity="0.6" />
            <stop offset="100%" stopColor={colors.stroke} stopOpacity="1" />
          </linearGradient>
        </defs>

        <circle
          cx={cx}
          cy={cy}
          r={radius}
          fill="none"
          stroke="rgba(255,255,255,0.06)"
          strokeWidth={stroke}
        />

        <circle
          cx={cx}
          cy={cy}
          r={radius + stroke * 0.8}
          fill="none"
          stroke={colors.stroke}
          strokeWidth={0.5}
          strokeOpacity={0.15}
        />

        <circle
          cx={cx}
          cy={cy}
          r={radius}
          fill="none"
          stroke={`url(#arcGradient)`}
          strokeWidth={stroke}
          strokeLinecap="round"
          strokeDasharray={circumference}
          strokeDashoffset={dashOffset}
          transform={`rotate(-90 ${cx} ${cy})`}
          filter="url(#glow)"
          style={{ transition: "stroke-dashoffset 0.05s linear" }}
        />

        {[...Array(12)].map((_, i) => {
          const angle = (i / 12) * 2 * Math.PI - Math.PI / 2;
          const r1 = radius - stroke;
          const r2 = radius - stroke * 1.5;
          return (
            <line
              key={i}
              x1={cx + r1 * Math.cos(angle)}
              y1={cy + r1 * Math.sin(angle)}
              x2={cx + r2 * Math.cos(angle)}
              y2={cy + r2 * Math.sin(angle)}
              stroke="rgba(255,255,255,0.15)"
              strokeWidth={1}
            />
          );
        })}
      </svg>

      <div className="flex flex-col items-center gap-1 z-10">
        {isCharging && (
          <span className="text-xs font-semibold tracking-widest uppercase opacity-70" style={{ color: colors.stroke }}>
            Charging
          </span>
        )}
        <div className={`font-bold tabular-nums leading-none ${colors.text}`} style={{ fontSize: size * 0.22 }}>
          {animated}
          <span style={{ fontSize: size * 0.1 }}>%</span>
        </div>
        <div className="text-xs text-white/40 tracking-widest uppercase font-medium">
          Battery
        </div>
      </div>

      <div
        className="absolute inset-0 rounded-full pointer-events-none"
        style={{
          background: `radial-gradient(circle at center, ${colors.glow.replace("0.5", "0.06")} 0%, transparent 70%)`,
        }}
      />
    </div>
  );
}
