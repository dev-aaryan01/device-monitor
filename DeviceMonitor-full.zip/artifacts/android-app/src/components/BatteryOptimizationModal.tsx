import { useEffect, useState } from "react";

interface BatteryOptimizationModalProps {
  open: boolean;
  onClose: () => void;
  onGoToSettings: () => void;
}

export function BatteryOptimizationModal({ open, onClose, onGoToSettings }: BatteryOptimizationModalProps) {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    if (open) {
      setVisible(true);
    } else {
      const t = setTimeout(() => setVisible(false), 250);
      return () => clearTimeout(t);
    }
  }, [open]);

  if (!visible) return null;

  return (
    <div
      className={`fixed inset-0 z-50 flex items-end sm:items-center justify-center p-4 transition-all duration-200 ${open ? "animate-overlay-in" : "opacity-0"}`}
      onClick={onClose}
    >
      <div
        className="absolute inset-0"
        style={{ background: "rgba(0,0,0,0.7)", backdropFilter: "blur(4px)" }}
      />

      <div
        className={`relative w-full max-w-sm rounded-2xl overflow-hidden z-10 ${open ? "animate-modal-in" : "opacity-0 scale-95"}`}
        onClick={(e) => e.stopPropagation()}
        style={{
          background: "rgba(12, 14, 22, 0.92)",
          backdropFilter: "blur(40px) saturate(180%)",
          border: "1px solid rgba(255,255,255,0.1)",
          boxShadow: "0 0 0 1px rgba(0,245,255,0.08), 0 32px 80px rgba(0,0,0,0.8), 0 0 60px rgba(0,245,255,0.06)",
        }}
      >
        <div
          className="absolute inset-x-0 top-0 h-px"
          style={{ background: "linear-gradient(90deg, transparent, rgba(0,245,255,0.5), rgba(191,90,242,0.5), transparent)" }}
        />

        <div className="absolute top-0 left-0 right-0 h-32 pointer-events-none overflow-hidden rounded-t-2xl">
          <div
            className="absolute inset-0"
            style={{
              background: "radial-gradient(ellipse at 50% 0%, rgba(0,245,255,0.07) 0%, transparent 70%)",
            }}
          />
        </div>

        <div className="p-6 pb-0 relative">
          <div className="flex items-start justify-between mb-5">
            <div className="flex items-center gap-3">
              <div
                className="w-11 h-11 rounded-2xl flex items-center justify-center flex-shrink-0"
                style={{
                  background: "rgba(0,245,255,0.1)",
                  border: "1px solid rgba(0,245,255,0.2)",
                  boxShadow: "0 0 20px rgba(0,245,255,0.15)",
                }}
              >
                <svg width="22" height="22" viewBox="0 0 24 24" fill="none">
                  <rect x="2" y="7" width="18" height="11" rx="2" stroke="#00f5ff" strokeWidth="1.5" />
                  <path d="M20 10.5h2v4h-2" stroke="#00f5ff" strokeWidth="1.5" strokeLinecap="round" />
                  <path d="M7 11.5l3 -1.5v3l3 -1.5" stroke="#00f5ff" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
                </svg>
              </div>
              <div>
                <h2 className="text-base font-bold text-white leading-tight">Battery Optimization</h2>
                <p className="text-xs text-white/40 mt-0.5">Required for background tasks</p>
              </div>
            </div>

            <button
              onClick={onClose}
              className="w-7 h-7 rounded-full flex items-center justify-center transition-all duration-200 hover:bg-white/10 active:scale-95"
            >
              <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
                <path d="M1 1l12 12M13 1L1 13" stroke="rgba(255,255,255,0.5)" strokeWidth="1.5" strokeLinecap="round" />
              </svg>
            </button>
          </div>

          <div
            className="rounded-xl p-4 mb-4"
            style={{
              background: "rgba(255,159,10,0.06)",
              border: "1px solid rgba(255,159,10,0.15)",
            }}
          >
            <div className="flex gap-3">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" className="flex-shrink-0 mt-0.5">
                <path d="M12 2L2 20h20L12 2z" stroke="#ff9f0a" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
                <path d="M12 9v5" stroke="#ff9f0a" strokeWidth="1.5" strokeLinecap="round" />
                <circle cx="12" cy="17" r="0.5" fill="#ff9f0a" stroke="#ff9f0a" strokeWidth="1" />
              </svg>
              <p className="text-xs leading-relaxed" style={{ color: "rgba(255,159,10,0.9)" }}>
                Android's battery optimization may silently terminate background tasks, causing missed notifications and sync failures.
              </p>
            </div>
          </div>

          <p className="text-sm text-white/60 leading-relaxed mb-5">
            To ensure this app runs reliably in the background, you'll need to{" "}
            <span className="text-white/90 font-medium">disable battery optimization</span>{" "}
            for it in your Android settings.
          </p>

          <div className="space-y-3 mb-6">
            {[
              { icon: "🔔", label: "Uninterrupted push notifications" },
              { icon: "🔄", label: "Continuous background data sync" },
              { icon: "⚡", label: "Reliable task scheduling" },
            ].map((item, i) => (
              <div key={i} className="flex items-center gap-3">
                <div
                  className="w-8 h-8 rounded-xl flex items-center justify-center text-sm flex-shrink-0"
                  style={{
                    background: "rgba(0,245,255,0.06)",
                    border: "1px solid rgba(0,245,255,0.1)",
                  }}
                >
                  {item.icon}
                </div>
                <span className="text-sm text-white/70">{item.label}</span>
              </div>
            ))}
          </div>
        </div>

        <div
          className="px-6 pb-6 pt-4 flex flex-col gap-3"
          style={{ borderTop: "1px solid rgba(255,255,255,0.06)" }}
        >
          <button
            onClick={onGoToSettings}
            className="w-full relative flex items-center justify-center gap-2.5 py-3.5 px-6 rounded-2xl font-semibold text-sm transition-all duration-200 active:scale-[0.97] overflow-hidden group"
            style={{
              background: "linear-gradient(135deg, rgba(0,245,255,0.15) 0%, rgba(191,90,242,0.15) 100%)",
              border: "1px solid rgba(0,245,255,0.3)",
              color: "#00f5ff",
              boxShadow: "0 0 20px rgba(0,245,255,0.15), inset 0 1px 0 rgba(255,255,255,0.08)",
            }}
          >
            <div
              className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-200"
              style={{
                background: "linear-gradient(135deg, rgba(0,245,255,0.08) 0%, rgba(191,90,242,0.08) 100%)",
              }}
            />
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" className="relative z-10">
              <path d="M12 2l2.4 4.8L20 8l-4 3.8.9 5.2L12 14.5l-4.9 2.5.9-5.2L4 8l5.6-1.2L12 2z" stroke="#00f5ff" strokeWidth="1.5" strokeLinejoin="round" />
            </svg>
            <span className="relative z-10" style={{ textShadow: "0 0 12px rgba(0,245,255,0.5)" }}>
              Go to Settings
            </span>
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" className="relative z-10 ml-auto">
              <path d="M5 12h14M13 6l6 6-6 6" stroke="#00f5ff" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          </button>

          <button
            onClick={onClose}
            className="w-full py-3 px-6 rounded-2xl text-sm font-medium text-white/40 transition-all duration-200 hover:text-white/60 active:scale-[0.97]"
          >
            Maybe Later
          </button>
        </div>
      </div>
    </div>
  );
}
