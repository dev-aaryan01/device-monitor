interface StatusBadgeProps {
  label: string;
  value: string;
  color: "cyan" | "green" | "purple" | "orange";
  icon?: React.ReactNode;
}

const colorMap = {
  cyan: {
    bg: "rgba(0,245,255,0.08)",
    border: "rgba(0,245,255,0.18)",
    text: "#00f5ff",
    dot: "#00f5ff",
  },
  green: {
    bg: "rgba(57,255,20,0.08)",
    border: "rgba(57,255,20,0.18)",
    text: "#39ff14",
    dot: "#39ff14",
  },
  purple: {
    bg: "rgba(191,90,242,0.08)",
    border: "rgba(191,90,242,0.18)",
    text: "#bf5af2",
    dot: "#bf5af2",
  },
  orange: {
    bg: "rgba(255,159,10,0.08)",
    border: "rgba(255,159,10,0.18)",
    text: "#ff9f0a",
    dot: "#ff9f0a",
  },
};

export function StatusBadge({ label, value, color, icon }: StatusBadgeProps) {
  const c = colorMap[color];
  return (
    <div
      className="flex items-center gap-2 px-3 py-2 rounded-xl"
      style={{ background: c.bg, border: `1px solid ${c.border}` }}
    >
      {icon ? (
        <span style={{ color: c.text }}>{icon}</span>
      ) : (
        <span
          className="w-2 h-2 rounded-full animate-pulse-neon flex-shrink-0"
          style={{ background: c.dot, boxShadow: `0 0 6px ${c.dot}` }}
        />
      )}
      <div className="flex flex-col">
        <span className="text-xs font-semibold" style={{ color: c.text }}>{value}</span>
        <span className="text-xs text-white/40 leading-none">{label}</span>
      </div>
    </div>
  );
}
