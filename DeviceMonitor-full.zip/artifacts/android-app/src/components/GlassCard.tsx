import { ReactNode } from "react";

interface GlassCardProps {
  children: ReactNode;
  className?: string;
  gradientBorder?: boolean;
  glowColor?: string;
}

export function GlassCard({ children, className = "", gradientBorder = false, glowColor }: GlassCardProps) {
  return (
    <div
      className={`relative rounded-2xl overflow-hidden ${className}`}
      style={{
        background: "rgba(255,255,255,0.04)",
        backdropFilter: "blur(24px) saturate(180%)",
        WebkitBackdropFilter: "blur(24px) saturate(180%)",
        border: gradientBorder ? "none" : "1px solid rgba(255,255,255,0.08)",
        boxShadow: glowColor
          ? `0 0 40px ${glowColor}20, 0 8px 32px rgba(0,0,0,0.4)`
          : "0 8px 32px rgba(0,0,0,0.4)",
      }}
    >
      {gradientBorder && (
        <div
          className="absolute inset-0 rounded-2xl pointer-events-none"
          style={{
            padding: "1px",
            background: "linear-gradient(135deg, rgba(0,245,255,0.25), rgba(191,90,242,0.25))",
            WebkitMask: "linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0)",
            WebkitMaskComposite: "xor",
            maskComposite: "exclude",
          }}
        />
      )}
      {children}
    </div>
  );
}
