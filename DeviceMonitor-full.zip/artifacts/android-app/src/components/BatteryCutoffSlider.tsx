import { useRef } from "react";

interface BatteryCutoffSliderProps {
  value: number;
  onChange: (value: number) => void;
  min?: number;
  max?: number;
  currentBattery?: number;
}

export function BatteryCutoffSlider({
  value,
  onChange,
  min = 50,
  max = 100,
  currentBattery,
}: BatteryCutoffSliderProps) {
  const inputRef = useRef<HTMLInputElement>(null);
  const pct = ((value - min) / (max - min)) * 100;
  const willTrigger = currentBattery !== undefined && currentBattery >= value;

  return (
    <div
      className="w-full rounded-2xl p-5"
      style={{
        background: "rgba(255,255,255,0.03)",
        border: "1px solid rgba(255,255,255,0.08)",
      }}
    >
      <div className="flex items-center justify-between mb-4">
        <div>
          <p className="text-sm font-semibold text-white">Beep Threshold</p>
          <p className="text-xs text-white/40 mt-0.5">5-sec beep when battery reaches this %</p>
        </div>
        <div
          className="px-3.5 py-1.5 rounded-xl text-sm font-bold tabular-nums"
          style={{
            background: willTrigger ? "rgba(255,59,48,0.15)" : "rgba(0,245,255,0.1)",
            border: `1px solid ${willTrigger ? "rgba(255,59,48,0.3)" : "rgba(0,245,255,0.25)"}`,
            color: willTrigger ? "#ff3b30" : "#00f5ff",
            boxShadow: willTrigger
              ? "0 0 14px rgba(255,59,48,0.2)"
              : "0 0 14px rgba(0,245,255,0.15)",
          }}
        >
          {value}%
        </div>
      </div>

      {/* Track */}
      <div className="relative mb-5">
        <div
          className="w-full h-2 rounded-full overflow-hidden"
          style={{ background: "rgba(255,255,255,0.08)" }}
        >
          <div
            className="h-full rounded-full transition-all duration-150"
            style={{
              width: `${pct}%`,
              background: willTrigger
                ? "linear-gradient(90deg, rgba(255,59,48,0.6), #ff3b30)"
                : "linear-gradient(90deg, rgba(0,245,255,0.5), #00f5ff)",
              boxShadow: willTrigger
                ? "0 0 8px rgba(255,59,48,0.5)"
                : "0 0 8px rgba(0,245,255,0.4)",
            }}
          />
        </div>

        {/* Current battery marker */}
        {currentBattery !== undefined && (
          <div
            className="absolute top-1/2 -translate-y-1/2 w-2.5 h-4 rounded-sm pointer-events-none transition-all duration-500"
            style={{
              left: `calc(${Math.max(0, Math.min(100, ((currentBattery - min) / (max - min)) * 100))}% - 5px)`,
              background: "rgba(57,255,20,0.9)",
              boxShadow: "0 0 8px rgba(57,255,20,0.6)",
            }}
          />
        )}

        {/* Hidden range input */}
        <input
          ref={inputRef}
          type="range"
          min={min}
          max={max}
          value={value}
          onChange={(e) => onChange(Number(e.target.value))}
          className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
          style={{ zIndex: 10 }}
        />

        {/* Custom thumb */}
        <div
          className="absolute top-1/2 -translate-y-1/2 w-5 h-5 rounded-full border-2 pointer-events-none transition-all duration-150"
          style={{
            left: `calc(${pct}% - 10px)`,
            background: willTrigger ? "#ff3b30" : "#00f5ff",
            borderColor: "rgba(255,255,255,0.4)",
            boxShadow: willTrigger
              ? "0 0 12px rgba(255,59,48,0.7), 0 2px 8px rgba(0,0,0,0.5)"
              : "0 0 12px rgba(0,245,255,0.7), 0 2px 8px rgba(0,0,0,0.5)",
          }}
        />
      </div>

      {/* Scale labels */}
      <div className="flex justify-between text-xs text-white/30 font-medium mb-2">
        <span>{min}%</span>
        {[60, 70, 80, 90].map((v) => (
          <span key={v} className="text-white/20">{v}</span>
        ))}
        <span>{max}%</span>
      </div>

      {/* Info row */}
      <div className="flex items-center justify-between">
        {currentBattery !== undefined && (
          <span
            className="px-2 py-0.5 rounded-md text-xs"
            style={{
              background: "rgba(57,255,20,0.08)",
              color: "rgba(57,255,20,0.8)",
              border: "1px solid rgba(57,255,20,0.15)",
            }}
          >
            Now: {currentBattery}%
          </span>
        )}
        <span className="text-xs text-white/30 ml-auto">One-shot · 5 sec beep</span>
      </div>

      {willTrigger && (
        <div
          className="mt-3 flex items-center gap-2 px-3 py-2 rounded-xl"
          style={{
            background: "rgba(255,59,48,0.08)",
            border: "1px solid rgba(255,59,48,0.2)",
          }}
        >
          <span
            className="w-2 h-2 rounded-full flex-shrink-0 animate-pulse-neon"
            style={{ background: "#ff3b30", boxShadow: "0 0 6px #ff3b30" }}
          />
          <span className="text-xs font-medium" style={{ color: "rgba(255,59,48,0.9)" }}>
            Threshold met — beep will fire!
          </span>
        </div>
      )}
    </div>
  );
}
