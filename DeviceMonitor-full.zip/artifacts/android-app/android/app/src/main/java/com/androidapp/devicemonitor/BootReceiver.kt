package com.androidapp.devicemonitor

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import android.util.Log

/**
 * BootReceiver
 *
 * Automatically restarts BatteryMonitorService after the device reboots,
 * but only if the Master Toggle was ON when the device was last shut down.
 * State is persisted in SharedPreferences by BatteryMonitorService.
 */
class BootReceiver : BroadcastReceiver() {

    companion object {
        private const val TAG = "BootReceiver"
    }

    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action ?: return
        if (action != Intent.ACTION_BOOT_COMPLETED &&
            action != "android.intent.action.QUICKBOOT_POWERON" &&
            action != "com.htc.intent.action.QUICKBOOT_POWERON") return

        val prefs = context.getSharedPreferences(
            BatteryMonitorService.PREFS_NAME,
            Context.MODE_PRIVATE
        )
        val wasEnabled = prefs.getBoolean(BatteryMonitorService.PREF_ENABLED, false)

        if (!wasEnabled) {
            Log.d(TAG, "Monitor was OFF at shutdown — not restarting")
            return
        }

        val threshold = prefs.getInt(BatteryMonitorService.PREF_THRESHOLD, 90)
        val frequency = prefs.getInt(BatteryMonitorService.PREF_FREQUENCY, 1800)

        Log.d(TAG, "Boot received — restarting service (threshold=$threshold, freq=$frequency)")

        val serviceIntent = Intent(context, BatteryMonitorService::class.java).apply {
            action = BatteryMonitorService.ACTION_START
            putExtra(BatteryMonitorService.EXTRA_THRESHOLD, threshold)
            putExtra(BatteryMonitorService.EXTRA_FREQUENCY, frequency)
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            context.startForegroundService(serviceIntent)
        } else {
            context.startService(serviceIntent)
        }
    }
}
