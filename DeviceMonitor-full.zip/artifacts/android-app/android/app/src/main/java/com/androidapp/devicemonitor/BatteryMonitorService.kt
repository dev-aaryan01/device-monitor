package com.androidapp.devicemonitor

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.os.BatteryManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.util.Log
import androidx.core.app.NotificationCompat
import kotlin.math.sin

/**
 * BatteryMonitorService
 *
 * Behaviour:
 *  1. Starts as a Foreground Service with a persistent notification.
 *  2. Registers a battery broadcast receiver.
 *  3. When battery% >= threshold for the FIRST time:
 *       a. Plays a loud 1800 Hz sine-wave beep through AudioTrack
 *          (USAGE_MEDIA → routes to A2DP Bluetooth; calls stay on earpiece).
 *       b. After exactly BEEP_DURATION_MS (5 000 ms), stops the tone.
 *       c. Stops itself — job done.
 *  4. The Master Toggle OFF also stops this service.
 */
class BatteryMonitorService : Service() {

    companion object {
        private const val TAG = "BatteryMonitorSvc"
        private const val NOTIFICATION_ID = 1001
        private const val CHANNEL_ID   = "battery_monitor_channel"
        private const val CHANNEL_NAME = "Battery Monitor"

        const val ACTION_START = "com.androidapp.devicemonitor.START_MONITOR"
        const val ACTION_STOP  = "com.androidapp.devicemonitor.STOP_MONITOR"
        const val EXTRA_THRESHOLD = "threshold"
        const val EXTRA_FREQUENCY = "frequency"

        const val PREFS_NAME  = "BatteryMonitorPrefs"
        const val PREF_ENABLED   = "monitorEnabled"
        const val PREF_THRESHOLD = "threshold"
        const val PREF_FREQUENCY = "frequency"

        private const val BEEP_DURATION_MS = 5_000L   // 5 seconds — then auto-stop
    }

    private var threshold  = 90
    private var frequency  = 1800.0
    private var triggered  = false          // one-shot flag: fire once, then stop service

    private var audioTrack  : AudioTrack? = null
    private var audioThread : Thread?     = null
    private var wakeLock    : PowerManager.WakeLock? = null
    private val mainHandler = Handler(Looper.getMainLooper())

    // ── Battery broadcast receiver ──────────────────────────────────────────
    private val batteryReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            if (triggered) return                          // already fired — ignore further changes

            val level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
            val scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, -1)
            if (level < 0 || scale <= 0) return
            val pct = (level * 100) / scale

            Log.d(TAG, "Battery: $pct% | threshold: $threshold%")
            updateNotification(pct)

            if (pct >= threshold) {
                triggered = true
                Log.d(TAG, "Threshold reached → beep for ${BEEP_DURATION_MS}ms then stop")
                startBeepThenStop()
            }
        }
    }

    // ── Lifecycle ────────────────────────────────────────────────────────────
    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        acquireWakeLock()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            Log.d(TAG, "Stop action received")
            shutdownService(saveEnabled = false)
            return START_NOT_STICKY
        }

        threshold = intent?.getIntExtra(EXTRA_THRESHOLD, 90) ?: 90
        frequency = (intent?.getIntExtra(EXTRA_FREQUENCY, 1800) ?: 1800).toDouble()
        triggered = false

        // Persist so BootReceiver can restore
        prefs().edit()
            .putBoolean(PREF_ENABLED, true)
            .putInt(PREF_THRESHOLD, threshold)
            .putInt(PREF_FREQUENCY, frequency.toInt())
            .apply()

        startForeground(NOTIFICATION_ID, buildNotification("Waiting… battery below $threshold%", 0))
        registerBatteryReceiver()

        Log.d(TAG, "Service started — threshold=$threshold%, freq=${frequency}Hz")
        return START_STICKY
    }

    override fun onDestroy() {
        super.onDestroy()
        try { unregisterReceiver(batteryReceiver) } catch (_: Exception) {}
        stopTone()
        mainHandler.removeCallbacksAndMessages(null)
        wakeLock?.release()
        Log.d(TAG, "Service destroyed")
    }

    override fun onBind(intent: Intent?): IBinder? = null

    // ── Core logic: beep 5 s → auto-stop ────────────────────────────────────
    private fun startBeepThenStop() {
        startTone()
        updateNotification(-1)          // "Signal active" notification

        mainHandler.postDelayed({
            Log.d(TAG, "5 s elapsed — stopping tone and service")
            stopTone()
            // Post "done" notification briefly
            notify("✅ Done — charging reached $threshold%. Service stopped.", 0)
            shutdownService(saveEnabled = false)
        }, BEEP_DURATION_MS)
    }

    private fun shutdownService(saveEnabled: Boolean) {
        prefs().edit().putBoolean(PREF_ENABLED, saveEnabled).apply()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    // ── AudioTrack: sine wave → Bluetooth A2DP ───────────────────────────────
    private fun startTone() {
        val sampleRate  = 44100
        val minBuf = AudioTrack.getMinBufferSize(
            sampleRate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT
        ).coerceAtLeast(4096)

        val attrs = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_MEDIA)            // → Bluetooth A2DP
            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
            .build()

        val fmt = AudioFormat.Builder()
            .setSampleRate(sampleRate)
            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
            .build()

        // Max volume on STREAM_MUSIC — heard clearly through TWS
        val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val maxVol = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        am.setStreamVolume(AudioManager.STREAM_MUSIC, maxVol, 0)

        audioTrack = AudioTrack.Builder()
            .setAudioAttributes(attrs)
            .setAudioFormat(fmt)
            .setBufferSizeInBytes(minBuf)
            .setTransferMode(AudioTrack.MODE_STREAM)
            .build()
            .also { it.play() }

        val buf = ShortArray(minBuf)
        var phase = 0.0
        val phaseInc = 2.0 * Math.PI * frequency / sampleRate

        audioThread = Thread {
            while (!Thread.currentThread().isInterrupted) {
                for (i in buf.indices) {
                    buf[i] = (sin(phase) * Short.MAX_VALUE * 0.95).toInt().toShort()
                    phase += phaseInc
                    if (phase >= 2.0 * Math.PI) phase -= 2.0 * Math.PI
                }
                val written = audioTrack?.write(buf, 0, buf.size) ?: -1
                if (written < 0) break
            }
        }.also { it.isDaemon = true; it.start() }
    }

    private fun stopTone() {
        audioThread?.interrupt()
        audioThread = null
        runCatching { audioTrack?.stop() }
        runCatching { audioTrack?.release() }
        audioTrack = null
    }

    // ── Wake lock ────────────────────────────────────────────────────────────
    private fun acquireWakeLock() {
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(
            PowerManager.PARTIAL_WAKE_LOCK,
            "DeviceMonitor:WakeLock"
        ).also { it.acquire(6 * 60 * 60 * 1000L) }          // 6-hour max safety cap
    }

    // ── Battery receiver registration ────────────────────────────────────────
    private fun registerBatteryReceiver() {
        val filter = IntentFilter(Intent.ACTION_BATTERY_CHANGED)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(batteryReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("UnspecifiedRegisterReceiverFlag")
            registerReceiver(batteryReceiver, filter)
        }
    }

    // ── Notifications ─────────────────────────────────────────────────────────
    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ch = NotificationChannel(CHANNEL_ID, CHANNEL_NAME, NotificationManager.IMPORTANCE_LOW)
                .apply { description = "Battery threshold monitor"; setShowBadge(false) }
            (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(ch)
        }
    }

    private fun buildNotification(text: String, batteryLevel: Int): Notification {
        val tapIntent = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val stopIntent = PendingIntent.getService(
            this, 1,
            Intent(this, BatteryMonitorService::class.java).apply { action = ACTION_STOP },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val content = when {
            triggered -> "⚡ BEEPING — Signal to Bluetooth (5 sec)…"
            batteryLevel > 0 -> "🔋 $batteryLevel% — Waiting for $threshold% to beep"
            else -> text
        }
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Battery Monitor")
            .setContentText(content)
            .setSmallIcon(android.R.drawable.ic_lock_idle_charging)
            .setContentIntent(tapIntent)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .addAction(android.R.drawable.ic_delete, "Stop", stopIntent)
            .build()
    }

    private fun updateNotification(batteryLevel: Int) {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(NOTIFICATION_ID, buildNotification("Monitoring…", batteryLevel))
    }

    private fun notify(msg: String, batteryLevel: Int) {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val n = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Battery Monitor")
            .setContentText(msg)
            .setSmallIcon(android.R.drawable.ic_lock_idle_charging)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setAutoCancel(true)
            .build()
        nm.notify(NOTIFICATION_ID + 1, n)
    }

    private fun prefs() = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
}
