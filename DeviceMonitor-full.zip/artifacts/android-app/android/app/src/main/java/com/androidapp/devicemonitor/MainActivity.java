package com.androidapp.devicemonitor;

import android.os.Bundle;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        // Register the custom BatteryMonitorPlugin so the Capacitor JS bridge
        // can call startMonitor() / stopMonitor() / getStatus() from React.
        registerPlugin(BatteryMonitorPlugin.class);
        super.onCreate(savedInstanceState);
    }
}
