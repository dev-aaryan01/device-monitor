package com.androidapp.devicemonitor

import android.content.Context
import android.content.Intent
import android.os.Build
import com.getcapacitor.JSObject
import com.getcapacitor.Plugin
import com.getcapacitor.PluginCall
import com.getcapacitor.PluginMethod
import com.getcapacitor.annotation.CapacitorPlugin

/**
 * BatteryMonitorPlugin
 *
 * Capacitor bridge that lets the React/JS layer start and stop the native
 * BatteryMonitorService foreground service.
 *
 * JS usage (from the web layer):
 *   import { Capacitor } from '@capacitor/core';
 *
 *   // Start monitoring
 *   await Capacitor.Plugins.BatteryMonitorPlugin.startMonitor({
 *     threshold: 90,
 *     frequency: 1800,
 *   });
 *
 *   // Stop monitoring
 *   await Capacitor.Plugins.BatteryMonitorPlugin.stopMonitor();
 *
 *   // Query current status
 *   const { enabled, threshold } = await Capacitor.Plugins.BatteryMonitorPlugin.getStatus();
 */
@CapacitorPlugin(name = "BatteryMonitorPlugin")
class BatteryMonitorPlugin : Plugin() {

    @PluginMethod
    fun startMonitor(call: PluginCall) {
        val threshold = call.getInt("threshold", 90) ?: 90
        val frequency = call.getInt("frequency", 1800) ?: 1800

        val intent = Intent(context, BatteryMonitorService::class.java).apply {
            action = BatteryMonitorService.ACTION_START
            putExtra(BatteryMonitorService.EXTRA_THRESHOLD, threshold)
            putExtra(BatteryMonitorService.EXTRA_FREQUENCY, frequency)
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            context.startForegroundService(intent)
        } else {
            context.startService(intent)
        }

        val ret = JSObject()
        ret.put("success", true)
        ret.put("threshold", threshold)
        ret.put("frequency", frequency)
        call.resolve(ret)
    }

    @PluginMethod
    fun stopMonitor(call: PluginCall) {
        val intent = Intent(context, BatteryMonitorService::class.java).apply {
            action = BatteryMonitorService.ACTION_STOP
        }
        context.startService(intent)

        val ret = JSObject()
        ret.put("success", true)
        call.resolve(ret)
    }

    @PluginMethod
    fun getStatus(call: PluginCall) {
        val prefs = context.getSharedPreferences(
            BatteryMonitorService.PREFS_NAME,
            Context.MODE_PRIVATE
        )
        val ret = JSObject()
        ret.put("enabled", prefs.getBoolean(BatteryMonitorService.PREF_ENABLED, false))
        ret.put("threshold", prefs.getInt(BatteryMonitorService.PREF_THRESHOLD, 90))
        ret.put("frequency", prefs.getInt(BatteryMonitorService.PREF_FREQUENCY, 1800))
        call.resolve(ret)
    }
}
