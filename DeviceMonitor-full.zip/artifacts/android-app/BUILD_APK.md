# APK Banane ke 2 Tarike

---

## Tarika 1 — GitHub se (FREE, sirf phone chahiye) ✅ RECOMMENDED

### Step 1: GitHub account banao
- [github.com](https://github.com) par jao → Sign Up (free)

### Step 2: Naya repository banao
- GitHub par login ke baad: **+** button → **New repository**
- Name: `device-monitor`
- **Public** select karo → **Create repository**

### Step 3: Code upload karo (phone se bhi ho sakta hai)
GitHub repository page par:
- **"uploading an existing file"** link dabao
- **Poora project folder** drag-and-drop karo ya select karo
- **Commit changes** karo

### Step 4: APK automatically build hoga!
- Code upload hote hi **Actions tab** par build start ho jayega
- 5-10 minute wait karo
- Build khatam hone par: **Actions → Latest run → Artifacts → DeviceMonitor-debug-apk**
- **Download** karo → APK mil jayega!

### Step 5: Phone par install karo
1. Downloaded APK file phone par bhejo (WhatsApp/Gmail/Drive)
2. Phone mein: **Settings → Security → Unknown sources → ON**
3. APK file tap karo → **Install**
4. Done! 🎉

---

## Tarika 2 — Laptop se (Android Studio)

1. [developer.android.com/studio](https://developer.android.com/studio) download karo
2. Project open karo: `artifacts/android-app/android`
3. USB se phone connect karo (USB Debugging ON)
4. **▶ Run** dabao → seedha phone par install

---

## App kaise kaam karta hai

```
Toggle ON karo
    │
    ▼
Foreground Service start hota hai
Notification bar mein dikhta hai: "🔋 84% — Waiting for 90%"
    │
    ▼  (jab battery threshold par pahunche)
Bluetooth device ko 1800Hz beep — exactly 5 second
    │
    ▼
Service band ho jati hai
Notification: "✅ Done — charging reached 90%"
```

## Permissions jo AndroidManifest mein hain

| Permission | Kyun |
|---|---|
| `FOREGROUND_SERVICE` | Background mein chale bina maara jaye |
| `WAKE_LOCK` | Screen band hone par bhi CPU active rahe |
| `RECEIVE_BOOT_COMPLETED` | Phone restart hone par service dobara start |
| `POST_NOTIFICATIONS` | Status bar notification |
| `BLUETOOTH_CONNECT` | TWS device se connect |
| `MODIFY_AUDIO_SETTINGS` | Audio Bluetooth par route karna |
